"""Immutable per-session catalog context, independent of the generative model."""
from contextlib import contextmanager
import json

from scripts import new_bank_rag as rag
from scripts import new_bank_documents as docs
from scripts.knowledge_corpus import RetrievalSession


@contextmanager
def catalog_session(model_id):
    if model_id=='legacy_metadata':
        with RetrievalSession() as session:
            yield session
    elif model_id=='new_bank_2026':
        embeddings,model=rag.probe()
        documents=docs.build_documents()
        manifest=json.loads(rag.INDEX_PATH.read_text(encoding='utf-8'))
        session=rag.CatalogRetriever(None,documents,embeddings,model,model_id=model_id,
            corpus_id=manifest['corpus_id'],index_manifest=manifest,published=True)
        yield session
    else:
        raise ValueError('Unknown catalog; explicit supported model_id required')
