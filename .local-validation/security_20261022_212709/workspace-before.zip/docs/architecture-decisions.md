# Decisiones de consolidación

1. **Paquete pequeño con adaptadores de comandos.** `bank_governance` contiene el runtime reutilizable; `scripts.data_steward_agent` conserva imports y CLI. No se reescriben generadores ni publicadores que ya tienen restricciones probadas.
2. **PostgreSQL y pgvector.** Se conserva almacenamiento y aislamiento actuales. La mejora lexical usa el manifiesto inmutable de 82 documentos; FTS se difiere hasta justificar DDL con medición y ensayo aislado.
3. **LangChain y LangGraph tienen funciones distintas.** LangChain mantiene modelos, herramienta y salida estructurada. LangGraph aporta un grafo mínimo tipado; no añade un LLM coordinador ni especialistas inexistentes.
4. **Proveedores independientes de embeddings.** Ollama es el default; Gemini es opcional y requiere habilitación explícita. No hay fallback cloud ni llamadas remotas durante la consolidación.
5. **Conservar el extractivo.** La evaluación histórica A/B/C encontró límites reales de generación. Refactorizar no implica aceptar otro modelo de datos o modo por defecto.
6. **Contexto estructurado y volátil.** Se guardan temas y período, no hechos previos como evidencia. Cada turno recupera sus propias fuentes. No se añade otra base de memoria.
7. **Afirmaciones atómicas con límites explícitos.** Python comprueba referencias, operaciones tipadas y procedencia. El texto inferido sigue pendiente de revisión semántica; una operación válida no certifica una explicación entera.
8. **Historia conservada.** No se eliminan informes negativos, migraciones, manifiestos, fuentes ni respaldos. Los experimentos anteriores conservan comandos de reproducción, pero la guía central distingue su estado del runtime vigente.
9. **Pruebas de PostgreSQL seleccionadas.** La suite por defecto no habilita servicios. Solo las comprobaciones publicadas de lectura y el conjunto LLM pequeño se permiten sobre la base activa; los tests históricos con DDL/rollback no se ejecutan allí.
